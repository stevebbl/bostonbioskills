import React, { useMemo, useState } from "react";
import Papa from "papaparse";
import { saveAs } from "file-saver";
import {
  Document,
  Packer,
  Paragraph,
  HeadingLevel,
  TextRun,
  Table,
  TableRow,
  TableCell,
  WidthType,
  ImageRun,
} from "docx";

const DEFAULT_RATES: Record<string, number> = {
  "Lab Station Set-Up": 750,
  "Half-Day Lab Fee": 5000,
  "Full-Day Lab Fee": 8500,
  "Large Conference Room": 1200,
  "Small Conference Room": 800,
  "Specimen Holders (Plastic)": 150,
  "Support Staff / Coordination": 1800,
};

const LOCATIONS = ["Lexington, MA", "Providence, RI"] as const;

type RateCardParsed = {
  global: Record<string, number>;
  byLocation: Record<string, Record<string, number>>;
};

function parseRateCard(csvText: string): RateCardParsed {
  const parsed = Papa.parse(csvText, { header: true });
  const global: Record<string, number> = {};
  const byLocation: Record<string, Record<string, number>> = {};
  if (parsed?.data && Array.isArray(parsed.data)) {
    for (const row of parsed.data as any[]) {
      const sku = (row?.item_norm || "").toString().trim();
      if (!sku) continue;
      const med = parseFloat((row?.unit_median ?? row?.unit_median_num ?? row?.median ?? "").toString());
      if (!Number.isFinite(med)) continue;
      const locRaw = (row?.location ?? row?.location_hint ?? row?.Location ?? "").toString().trim();
      if (locRaw) {
        const loc = locRaw.toLowerCase().includes("providence") ? "Providence, RI" : "Lexington, MA";
        byLocation[loc] = byLocation[loc] || {};
        byLocation[loc][sku] = med;
      } else {
        global[sku] = med;
      }
    }
  }
  return { global, byLocation };
}

function currency(n: number) {
  return n.toLocaleString(undefined, { style: "currency", currency: "USD" });
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-white/80 backdrop-blur rounded-2xl shadow p-5 border border-slate-200">
      <h2 className="text-lg font-semibold mb-4">{title}</h2>
      {children}
    </div>
  );
}

export default function App() {
  // Rate card state
  const [globalRates, setGlobalRates] = useState<Record<string, number>>({});
  const [locRates, setLocRates] = useState<Record<string, Record<string, number>>>({});

  // Branding (preload from /public/logos)
  const [logoMain, setLogoMain] = useState<ArrayBuffer | null>(null);
  const [logoLoc, setLogoLoc] = useState<ArrayBuffer | null>(null);
  const [logoMainPreview, setLogoMainPreview] = useState<string | null>(null);
  const [logoLocPreview, setLogoLocPreview] = useState<string | null>(null);

  async function preloadLogo(url: string, setterBuf: (b: ArrayBuffer)=>void, setterPreview: (u:string)=>void) {
    const resp = await fetch(url);
    const buf = await resp.arrayBuffer();
    setterBuf(buf);
    setterPreview(url);
  }

  React.useEffect(() => {
    preloadLogo("/logos/bbl-main.png", setLogoMain, setLogoMainPreview).catch(()=>{});
  }, []);

  const [form, setForm] = useState({
    firstName: "",
    lastName: "",
    credentials: "",
    org: "",
    phone: "",
    email: "",

    location: "Lexington, MA" as (typeof LOCATIONS)[number],
    startDate: "",
    startTime: "08:00",
    endDate: "",
    endTime: "16:00",
    duration: "Half-Day" as "Half-Day" | "Full-Day",

    stations: 0,
    physicians: 0,
    reps: 0,

    wantLargeCR: false,
    wantSmallCR: false,

    specimenHolderDesc: "Plastic head holders",
    specimenHolderQty: 0,

    suction: "No",
    bovie: "No",
    remoteTraining: "No",

    clientEquipment: "",
    requestedEquipment: "",
  });

  React.useEffect(() => {
    const url = form.location.includes("Providence") ? "/logos/bbl-providence.png" : "/logos/bbl-main.png";
    preloadLogo(url, setLogoLoc, setLogoLocPreview).catch(()=>{});
  }, [form.location]);

  // Internal sign-off
  const [signoff, setSignoff] = useState({
    preparedBy: "",
    approverName: "",
    approverTitle: "",
    approvalDate: "",
  });

  const DISCOUNT_LIMITS: Record<string, number> = { Volume: 10, Partner: 15, Promo: 20, Custom: 0 };
  const [discount, setDiscount] = useState({
    type: "None" as "None" | "Volume" | "Partner" | "Promo" | "Custom",
    percent: 0,
    applyStations: true,
    applyLabFee: true,
    applyRooms: true,
    applyHolders: false,
    applySupport: false,
    approvalMaxPct: 20,
    managerApproved: false,
  });

  function update<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }
  function updateSign<K extends keyof typeof signoff>(key: K, value: (typeof signoff)[K]) {
    setSignoff((s) => ({ ...s, [key]: value }));
  }

  function loadSample() {
    setForm((f) => ({
      ...f,
      firstName: "Benjamin",
      lastName: "Keyser",
      credentials: "DMD, MD",
      org: "Greater Boston Oral Surgery",
      phone: "617-875-7827",
      email: "benrkeyser@gmail.com",
      location: "Lexington, MA",
      startDate: "2025-11-08",
      startTime: "08:00",
      endDate: "2025-11-08",
      endTime: "16:00",
      duration: "Half-Day",
      stations: 12,
      physicians: 24,
      reps: 2,
      wantLargeCR: true,
      wantSmallCR: true,
      specimenHolderDesc: "Plastic head holders",
      specimenHolderQty: 12,
      suction: "No",
      bovie: "No",
      remoteTraining: "No",
      clientEquipment: "Implant drills, implants, surgical instruments (some may be sourced externally).",
      requestedEquipment: "Instrument support as needed.",
    }));
    setSignoff({ preparedBy: "", approverName: "", approverTitle: "", approvalDate: "" });
  }

  function onUploadRateCard(file: File) {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const txt = String(reader.result || "");
        const rc = parseRateCard(txt);
        setGlobalRates(rc.global || {});
        setLocRates(rc.byLocation || {});
      } catch (e) {
        alert("Could not parse the uploaded rate card.");
      }
    };
    reader.readAsText(file);
  }

  function onUploadLogo(file: File, which: "main" | "loc") {
    const reader = new FileReader();
    reader.onload = () => {
      const buf = reader.result as ArrayBuffer;
      const url = URL.createObjectURL(new Blob([buf]));
      if (which === "main") { setLogoMain(buf); setLogoMainPreview(url); } else { setLogoLoc(buf); setLogoLocPreview(url); }
    };
    reader.readAsArrayBuffer(file);
  }

  function priceFor(sku: string): number {
    const rcLoc = locRates[form.location] || {};
    if (Number.isFinite(rcLoc[sku])) return Number(rcLoc[sku]);
    if (Number.isFinite(globalRates[sku])) return Number(globalRates[sku]);
    return DEFAULT_RATES[sku] ?? 0;
  }

  type Line = { item: string; qty: number; unit: number; total: number; elig: boolean };
  const baseLines: Line[] = useMemo(() => {
    const rows: Line[] = [];
    rows.push({ item: "Lab Station Set-Up", qty: Number(form.stations) || 0, unit: priceFor("Lab Station Set-Up"), total: 0, elig: discount.applyStations });
    const labSku = form.duration === "Half-Day" ? "Half-Day Lab Fee" : "Full-Day Lab Fee";
    rows.push({ item: labSku, qty: 1, unit: priceFor(labSku), total: 0, elig: discount.applyLabFee });
    if (form.wantLargeCR) rows.push({ item: "Large Conference Room", qty: 1, unit: priceFor("Large Conference Room"), total: 0, elig: discount.applyRooms });
    if (form.wantSmallCR) rows.push({ item: "Small Conference Room", qty: 1, unit: priceFor("Small Conference Room"), total: 0, elig: discount.applyRooms });
    rows.push({ item: "Specimen Holders (Plastic)", qty: Number(form.specimenHolderQty) || 0, unit: priceFor("Specimen Holders (Plastic)"), total: 0, elig: discount.applyHolders });
    rows.push({ item: "Support Staff / Coordination", qty: 1, unit: priceFor("Support Staff / Coordination"), total: 0, elig: discount.applySupport });
    for (const r of rows) r.total = (Number(r.qty) || 0) * (Number(r.unit) || 0);
    return rows;
  }, [form, globalRates, locRates, discount.applyStations, discount.applyLabFee, discount.applyRooms, discount.applyHolders, discount.applySupport]);

  const subtotal = useMemo(() => baseLines.reduce((a, b) => a + b.total, 0), [baseLines]);

  const autoLimit = discount.type === "None" ? 0 : DISCOUNT_LIMITS[discount.type] || 0;
  const needsApproval = discount.percent > autoLimit || discount.percent > discount.approvalMaxPct;

  const discounted = useMemo(() => {
    if (!discount.percent || discount.type === "None") return { lines: baseLines, discountTotal: 0, total: subtotal };
    const pct = Math.max(0, Number(discount.percent)) / 100;
    let discountTotal = 0;
    const lines = baseLines.map((r) => {
      if (!r.elig) return { ...r };
      const cut = r.total * pct;
      discountTotal += cut;
      return { ...r, total: r.total - cut };
    });
    const total = lines.reduce((a, b) => a + b.total, 0);
    return { lines, discountTotal, total };
  }, [baseLines, discount.percent, discount.type, subtotal]);

  const tax = 0;
  const grand = discounted.total + tax;

  function downloadCSV() {
    const header = "Item,Qty,Unit,Total\n";
    const body = discounted.lines.map((r) => `${JSON.stringify(r.item)},${r.qty},${r.unit},${r.total}`).join("\n");
    const tail = `\nDiscount,,,-${discounted.discountTotal}\nSubtotal,,,${discounted.total}\nTax,,,${tax}\nTotal,,,${grand}`;
    const blob = new Blob([header + body + tail], { type: "text/csv;charset=utf-8" });
    saveAs(blob, `BBL_LineItems_${Date.now()}.csv`);
  }

  function arrBufToImageRun(buf: ArrayBuffer | null, width = 420, height?: number) {
    if (!buf) return undefined as any;
    return new ImageRun({ data: new Uint8Array(buf), transformation: { width, height: height ?? Math.round(width * 0.32) } });
  }

  async function downloadDocx() {
    const rows = discounted.lines;
    const docChildren: any[] = [];

    const mainLogoRun = arrBufToImageRun(logoMain, 420);
    const locLogoRun = arrBufToImageRun(logoLoc, 420);
    if (mainLogoRun || locLogoRun) {
      if (mainLogoRun) docChildren.push(new Paragraph({ children: [mainLogoRun] }));
      if (locLogoRun) docChildren.push(new Paragraph({ children: [locLogoRun] }));
      docChildren.push(new Paragraph(""));
    }

    docChildren.push(new Paragraph({ text: "Surgical Training Proposal & Quote", heading: HeadingLevel.TITLE }));

    docChildren.push(new Paragraph({ children: [new TextRun({ text: "Prepared for:", bold: true })] }));
    docChildren.push(new Paragraph(`${form.firstName ? `Dr. ${form.firstName} ${form.lastName}` : "Client"}${form.credentials ? `, ${form.credentials}` : ""}`));
    if (form.org) docChildren.push(new Paragraph(form.org));
    docChildren.push(new Paragraph(`Contact: ${form.phone || ""} | ${form.email || ""}`));

    docChildren.push(new Paragraph(""));
    docChildren.push(new Paragraph({ children: [new TextRun({ text: "Event Information:", bold: true })] }));
    docChildren.push(new Paragraph(`Location: ${form.location}`));
    docChildren.push(new Paragraph(`Date: ${form.startDate || "TBD"} (${form.startTime || ""} – ${form.endTime || ""})`));
    docChildren.push(new Paragraph(`Duration: ${form.duration} Lab (1 Day)`));
    docChildren.push(new Paragraph(`Participants: ${form.physicians || 0} Physicians | ${form.stations || 0} Stations | ${form.reps || 0} Industry Reps`));

    docChildren.push(new Paragraph({ text: "Event Summary", heading: HeadingLevel.HEADING_2 }));
    const rooms = [form.wantLargeCR ? "Large Conference Room" : null, form.wantSmallCR ? "Small Conference Room" : null].filter(Boolean).join(", ") || "None";
    docChildren.push(new Paragraph(`Requested meeting spaces: ${rooms}`));
    docChildren.push(new Paragraph(`Specimen Needs: ${form.specimenHolderQty || 0} holders (${form.specimenHolderDesc || "N/A"})`));
    docChildren.push(new Paragraph(`Equipment provided by client: ${form.clientEquipment || "N/A"}`));
    docChildren.push(new Paragraph(`Requested equipment from lab: ${form.requestedEquipment || "N/A"}`));
    docChildren.push(new Paragraph(`Remote Training: ${form.remoteTraining || "No"}`));

    docChildren.push(new Paragraph({ text: "Line Item Quote (Historical Medians Applied)", heading: HeadingLevel.HEADING_2 }));
    const tableRows: any[] = [
      new TableRow({
        children: [
          new TableCell({ children: [new Paragraph("Item")] }),
          new TableCell({ children: [new Paragraph("Qty")] }),
          new TableCell({ children: [new Paragraph("Unit Price")] }),
          new TableCell({ children: [new Paragraph("Total")] }),
        ],
      }),
      ...rows.map(
        (r) =>
          new TableRow({
            children: [
              new TableCell({ children: [new Paragraph(r.item)] }),
              new TableCell({ children: [new Paragraph(String(r.qty))] }),
              new TableCell({ children: [new Paragraph(currency(r.unit))] }),
              new TableCell({ children: [new Paragraph(currency(r.total))] }),
            ],
          })
      ),
      new TableRow({
        children: [
          new TableCell({ children: [new Paragraph("Discount")] }),
          new TableCell({ children: [new Paragraph("")] }),
          new TableCell({ children: [new Paragraph("")] }),
          new TableCell({ children: [new Paragraph(`-${currency(discounted.discountTotal)}`)] }),
        ],
      }),
      new TableRow({
        children: [
          new TableCell({ children: [new Paragraph("Subtotal")] }),
          new TableCell({ children: [new Paragraph("")] }),
          new TableCell({ children: [new Paragraph("")] }),
          new TableCell({ children: [new Paragraph(currency(discounted.total))] }),
        ],
      }),
      new TableRow({
        children: [
          new TableCell({ children: [new Paragraph("Tax")] }),
          new TableCell({ children: [new Paragraph("")] }),
          new TableCell({ children: [new Paragraph("")] }),
          new TableCell({ children: [new Paragraph(currency(0))] }),
        ],
      }),
      new TableRow({
        children: [
          new TableCell({ children: [new Paragraph("Total")] }),
          new TableCell({ children: [new Paragraph("")] }),
          new TableCell({ children: [new Paragraph("")] }),
          new TableCell({ children: [new Paragraph(currency(grand))] }),
        ],
      }),
    ];
    docChildren.push(new Table({ width: { size: 100, type: WidthType.PERCENTAGE }, rows: tableRows }));

    docChildren.push(new Paragraph({ text: "Similar Past Events", heading: HeadingLevel.HEADING_2 }));
    docChildren.push(
      new Paragraph(
        `Quote reflects median historical pricing per item${locRates[form.location] ? ` for ${form.location}` : ""}. ${
          discount.type !== "None" ? `Discount applied: ${discount.percent}% (${discount.type}).` : "No discount applied."
        }`
      )
    );

    docChildren.push(new Paragraph({ text: "Terms & Next Steps", heading: HeadingLevel.HEADING_2 }));
    docChildren.push(
      new Paragraph(
        "• Proposal valid for 30 days\n• 50% deposit due upon booking\n• Remaining balance due 14 days before event\n• Contact Boston Bioskills Lab for adjustments or special requests"
      )
    );

    // Internal Sign-Off
    docChildren.push(new Paragraph({ text: "Internal Sign-Off", heading: HeadingLevel.HEADING_2 }));
    const signRows: any[] = [
      new TableRow({
        children: [
          new TableCell({ children: [new Paragraph("Prepared By"), new Paragraph(signoff.preparedBy || "________________________")] }),
          new TableCell({ children: [new Paragraph("Date"), new Paragraph(signoff.approvalDate || "________________")] }),
        ],
      }),
      new TableRow({
        children: [
          new TableCell({
            children: [
              new Paragraph("Pricing Approved By"),
              new Paragraph((signoff.approverName || "________________________") + (signoff.approverTitle ? `, ${signoff.approverTitle}` : "")),
            ],
          }),
          new TableCell({ children: [new Paragraph("Signature"), new Paragraph("________________________")] }),
        ],
      }),
    ];
    docChildren.push(new Table({ width: { size: 100, type: WidthType.PERCENTAGE }, rows: signRows }));

    const doc = new Document({ sections: [{ properties: {}, children: docChildren }] });
    const blob = await Packer.toBlob(doc);
    saveAs(blob, `BBL_Proposal_${form.lastName || "Client"}.docx`);
  }

  function sendForSignature() {
    downloadDocx();
    const subject = encodeURIComponent(`BBL Proposal – ${form.firstName ? "Dr. " + form.firstName + " " + form.lastName : "Client"} (${form.location})`);
    const body = encodeURIComponent(
      `Hi ${form.firstName || ""},\n\nAttached is your proposal for ${form.location} on ${form.startDate || "TBD"}. Please review and reply to proceed to e-signature.\n\nBest,\nBoston Bioskills Lab`
    );
    window.location.href = `mailto:${form.email || ""}?subject=${subject}&body=${body}`;
  }

  const discountAutoLimit = discount.type === "None" ? 0 : DISCOUNT_LIMITS[discount.type] || 0;

  return (
    <div className="min-h-screen w-full bg-gradient-to-b from-slate-50 to-slate-100 text-slate-900">
      <div className="max-w-7xl mx-auto p-6 md:p-10">
        <header className="mb-6">
          <div className="flex items-center justify-between gap-4">
            <h1 className="text-2xl md:text-3xl font-bold">BBL Quote Builder</h1>
            <div className="flex flex-wrap gap-3">
              <label className="cursor-pointer inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm shadow-sm hover:bg-slate-50">
                <input type="file" accept=".csv,text/csv" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) onUploadRateCard(f); }} />
                Upload RateCard CSV
              </label>
              <label className="cursor-pointer inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm shadow-sm hover:bg-slate-50">
                <input type="file" accept="image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) onUploadLogo(f, "main"); }} />
                Upload Brand Logo
              </label>
              <label className="cursor-pointer inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm shadow-sm hover:bg-slate-50">
                <input type="file" accept="image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) onUploadLogo(f, "loc"); }} />
                Upload Location Logo
              </label>
              <button onClick={loadSample} className="rounded-xl bg-slate-900 text-white px-4 py-2 text-sm shadow hover:bg-slate-800">Load Sample (Keyser)</button>
            </div>
          </div>
          <div className="mt-3 flex items-center gap-4">
            {logoMainPreview && <img src={logoMainPreview} alt="Brand logo" className="h-10 object-contain" />}
            {logoLocPreview && <img src={logoLocPreview} alt="Location logo" className="h-10 object-contain" />}
          </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Section title="Contact Information">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <input className="input" placeholder="First name" value={form.firstName} onChange={(e)=>update("firstName", e.target.value)} />
              <input className="input" placeholder="Last name" value={form.lastName} onChange={(e)=>update("lastName", e.target.value)} />
              <input className="input md:col-span-2" placeholder="Credentials (MD, DMD, etc.)" value={form.credentials} onChange={(e)=>update("credentials", e.target.value)} />
              <input className="input md:col-span-2" placeholder="Institution / Practice" value={form.org} onChange={(e)=>update("org", e.target.value)} />
              <input className="input" placeholder="Phone" value={form.phone} onChange={(e)=>update("phone", e.target.value)} />
              <input className="input" placeholder="Email" value={form.email} onChange={(e)=>update("email", e.target.value)} />
            </div>
          </Section>

          <Section title="Event Details">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <label className="label md:col-span-2">Location
                <select className="input" value={form.location} onChange={(e)=>update("location", e.target.value as any)}>
                  {LOCATIONS.map((L)=> <option key={L}>{L}</option>)}
                </select>
              </label>
              <label className="label">Start Date<input type="date" className="input" value={form.startDate} onChange={(e)=>update("startDate", e.target.value)} /></label>
              <label className="label">Start Time<input type="time" className="input" value={form.startTime} onChange={(e)=>update("startTime", e.target.value)} /></label>
              <label className="label">End Date<input type="date" className="input" value={form.endDate} onChange={(e)=>update("endDate", e.target.value)} /></label>
              <label className="label">End Time<input type="time" className="input" value={form.endTime} onChange={(e)=>update("endTime", e.target.value)} /></label>
              <label className="label md:col-span-2">Duration
                <select className="input" value={form.duration} onChange={(e)=>update("duration", e.target.value as any)}>
                  <option>Half-Day</option>
                  <option>Full-Day</option>
                </select>
              </label>
              <label className="label"># Stations<input type="number" className="input" value={form.stations} onChange={(e)=>update("stations", Number(e.target.value))} /></label>
              <label className="label"># Physicians<input type="number" className="input" value={form.physicians} onChange={(e)=>update("physicians", Number(e.target.value))} /></label>
              <label className="label"># Industry Reps<input type="number" className="input" value={form.reps} onChange={(e)=>update("reps", Number(e.target.value))} /></label>
              <div className="flex items-center gap-4 md:col-span-2">
                <label className="flex items-center gap-2"><input type="checkbox" checked={form.wantLargeCR} onChange={(e)=>update("wantLargeCR", e.target.checked)} /> Large Conf Room</label>
                <label className="flex items-center gap-2"><input type="checkbox" checked={form.wantSmallCR} onChange={(e)=>update("wantSmallCR", e.target.checked)} /> Small Conf Room</label>
              </div>
            </div>
          </Section>

          <Section title="Specimen & Equipment">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <label className="label">Specimen Holder Type<input className="input" value={form.specimenHolderDesc} onChange={(e)=>update("specimenHolderDesc", e.target.value)} /></label>
              <label className="label">Specimen Holder Qty<input type="number" className="input" value={form.specimenHolderQty} onChange={(e)=>update("specimenHolderQty", Number(e.target.value))} /></label>
              <label className="label">Suction<select className="input" value={form.suction} onChange={(e)=>update("suction", e.target.value)}><option>No</option><option>Yes</option></select></label>
              <label className="label">Bovie<select className="input" value={form.bovie} onChange={(e)=>update("bovie", e.target.value)}><option>No</option><option>Yes</option></select></label>
              <label className="label md:col-span-2">Client-Provided Equipment<textarea className="input min-h-[90px]" value={form.clientEquipment} onChange={(e)=>update("clientEquipment", e.target.value)} /></label>
              <label className="label md:col-span-2">Requested Equipment<textarea className="input min-h-[90px]" value={form.requestedEquipment} onChange={(e)=>update("requestedEquipment", e.target.value)} /></label>
              <label className="label md:col-span-2">Remote Training<select className="input" value={form.remoteTraining} onChange={(e)=>update("remoteTraining", e.target.value)}><option>No</option><option>Yes</option></select></label>
            </div>
          </Section>

          <Section title="Discounts & Approvals">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <label className="label md:col-span-2">Discount Type
                <select className="input" value={discount.type} onChange={(e)=>setDiscount((d)=>({ ...d, type: e.target.value as any }))}>
                  <option>None</option>
                  <option>Volume</option>
                  <option>Partner</option>
                  <option>Promo</option>
                  <option>Custom</option>
                </select>
              </label>
              <label className="label">Discount %<input type="number" className="input" value={discount.percent} onChange={(e)=>setDiscount((d)=>({ ...d, percent: Number(e.target.value) }))} /></label>
              <label className="label">Approval Guardrail %<input type="number" className="input" value={discount.approvalMaxPct} onChange={(e)=>setDiscount((d)=>({ ...d, approvalMaxPct: Number(e.target.value) }))} /></label>
              <div className="md:col-span-2 flex flex-wrap gap-4">
                <label className="flex items-center gap-2"><input type="checkbox" checked={discount.applyStations} onChange={(e)=>setDiscount((d)=>({ ...d, applyStations: e.target.checked }))}/> Stations</label>
                <label className="flex items-center gap-2"><input type="checkbox" checked={discount.applyLabFee} onChange={(e)=>setDiscount((d)=>({ ...d, applyLabFee: e.target.checked }))}/> Lab Fee</label>
                <label className="flex items-center gap-2"><input type="checkbox" checked={discount.applyRooms} onChange={(e)=>setDiscount((d)=>({ ...d, applyRooms: e.target.checked }))}/> Rooms</label>
                <label className="flex items-center gap-2"><input type="checkbox" checked={discount.applyHolders} onChange={(e)=>setDiscount((d)=>({ ...d, applyHolders: e.target.checked }))}/> Holders</label>
                <label className="flex items-center gap-2"><input type="checkbox" checked={discount.applySupport} onChange={(e)=>setDiscount((d)=>({ ...d, applySupport: e.target.checked }))}/> Support</label>
              </div>
              <div className={`md:col-span-2 text-sm ${discount.type!=="None" && needsApproval && !discount.managerApproved ? "text-red-600" : "text-emerald-700"}`}>
                {discount.type === "None" ? (
                  <span>No discount applied.</span>
                ) : needsApproval && !discount.managerApproved ? (
                  <span>Discount exceeds auto-limit ({autoLimit}% for {discount.type}) or guardrail ({discount.approvalMaxPct}%). <strong>Manager approval required.</strong></span>
                ) : (
                  <span>Discount within auto-approval limits.</span>
                )}
              </div>
              <label className="label">Manager Approved?
                <input type="checkbox" checked={discount.managerApproved} onChange={(e)=>setDiscount((d)=>({ ...d, managerApproved: e.target.checked }))} />
              </label>
            </div>
          </Section>

          <Section title="Internal Sign-Off (for DOCX footer)">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <label className="label">Prepared By<input className="input" value={signoff.preparedBy} onChange={(e)=>updateSign("preparedBy", e.target.value)} /></label>
              <label className="label">Approval Date<input type="date" className="input" value={signoff.approvalDate} onChange={(e)=>updateSign("approvalDate", e.target.value)} /></label>
              <label className="label md:col-span-2">Approver Name<input className="input" value={signoff.approverName} onChange={(e)=>updateSign("approverName", e.target.value)} /></label>
              <label className="label md:col-span-2">Approver Title<input className="input" value={signoff.approverTitle} onChange={(e)=>updateSign("approverTitle", e.target.value)} /></label>
            </div>
          </Section>

          <Section title="Pricing Preview">
            <div className="text-sm text-slate-600 mb-2">Using {locRates[form.location] ? `${form.location} medians` : globalRates && Object.keys(globalRates).length ? "global medians" : "default rates"}.</div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-slate-600 border-b">
                    <th className="py-2 pr-3">Item</th>
                    <th className="py-2 pr-3">Qty</th>
                    <th className="py-2 pr-3">Unit</th>
                    <th className="py-2 pr-3">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {discounted.lines.map((r, i) => (
                    <tr key={i} className="border-b last:border-b-0">
                      <td className="py-2 pr-3">{r.item}</td>
                      <td className="py-2 pr-3">{r.qty}</td>
                      <td className="py-2 pr-3">{currency(r.unit)}</td>
                      <td className="py-2 pr-3 font-medium">{currency(r.total)}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr>
                    <td className="py-2 pr-3 font-semibold">Discount</td>
                    <td></td><td></td>
                    <td className="py-2 pr-3 font-semibold">-{currency(discounted.discountTotal)}</td>
                  </tr>
                  <tr>
                    <td className="py-2 pr-3 font-semibold">Subtotal</td>
                    <td></td><td></td>
                    <td className="py-2 pr-3 font-semibold">{currency(discounted.total)}</td>
                  </tr>
                  <tr>
                    <td className="py-2 pr-3 font-semibold">Tax</td>
                    <td></td><td></td>
                    <td className="py-2 pr-3 font-semibold">{currency(0)}</td>
                  </tr>
                  <tr>
                    <td className="py-2 pr-3 font-semibold">Total</td>
                    <td></td><td></td>
                    <td className="py-2 pr-3 font-semibold">{currency(grand)}</td>
                  </tr>
                </tfoot>
              </table>
            </div>

            <div className="mt-4 flex flex-wrap gap-3">
              <button onClick={downloadDocx} className="rounded-xl bg-emerald-600 text-white px-4 py-2 text-sm shadow hover:bg-emerald-700">Download DOCX Proposal</button>
              <button onClick={downloadCSV} className="rounded-xl bg-slate-900 text-white px-4 py-2 text-sm shadow hover:bg-slate-800">Download Line Items CSV</button>
              <button onClick={sendForSignature} className="rounded-xl bg-red-600 text-white px-4 py-2 text-sm shadow hover:bg-red-700">Send for Signature</button>
              <div className="text-xs text-slate-500 self-center">Upload a RateCard CSV with a <code>location</code> column to enable location-specific medians.</div>
            </div>
          </Section>
        </div>

        <footer className="mt-8 text-xs text-slate-500">© {new Date().getFullYear()} Boston Bioskills Lab – Internal Quote Builder</footer>
      </div>
    </div>
  );
}
